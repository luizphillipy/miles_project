require("../data/travellers-model")
const mongoose = require("mongoose");

const Traveller = mongoose.model(process.env.TRAVELLER_MODEL);


const getAll = function(req,res){
    console.log("GET Traveller Controller");
    let count =10;
    let offset =0;
    if(req.query && req.query.count){
        offset = parseInt(req.query.count,10);
    }
    if(req.query && req.query.offset){
        offset = parseInt(req.query.offset,10);
    }
    Traveller.find().skip(offset).limit(count).exec(function(err,travellers){
        if(err){
            console.log("No traveller was found: ",err);
        }
        console.log("Travellers found: ",travellers.length);
        res.status(200).json(travellers);
    });
}
const getOne = function(req,res){
    const travellerId = req.params.travellerId;
    Traveller.findById(travellerId).exec(function(err,traveller){
        if(err){
            console.log("TravellerId not found");
            res.status(404).send("TravellerId not found")
        }
        res.status(200).json(traveller);
    });

};

const deleteOne = function(req,res){
    const travellerId = req.params.travellerId;
    console.log("DELETE controller Request");
    Traveller.findByIdAndDelete(travellerId).exec(function(err, traveller){
        if(err){
            console.log("travellerId not found");
            res.status(404).send("TravellerId not found");
        };
        console.log("Traveller was sucessfully removed: ",traveller);
        const response = {status:204,message:traveller};
        res.status(response.status).json(response.message)



    })
}

const addOne = function(req,res){
    console.log("Traveller AddOne Requested");
   


    const newTraveller = {
        name:req.body.name, 
        passport:req.body.passport, 
        nationality:req.body.nationality,
        loyaltyPrograms:[{
            name:req.body.lname,
            memberId:req.body.memberId,
            milesAmount:req.body.milesAmount
        }]
    };
    Traveller.create(newTraveller, function(err,traveller){
        const response = {status:201,message:traveller};
        if(err){
            console.log("Error creating Traveller");
            response.status=500;
            response.message=err;

        }
        res.status(response.status).json(response.message);
    })
}
module.exports={getAll, getOne, addOne, deleteOne}